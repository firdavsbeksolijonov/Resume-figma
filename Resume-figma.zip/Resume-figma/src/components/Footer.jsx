import React from 'react'
import FooterImg from "../images/footer-img-7.png"
const Footer = () => {
  return (
    <div className='h-[196px] flex items-center justify-center  px-[148px] mt-[85px]'>
      <a href="#">
      <img src={FooterImg} alt="footer-imag" />
      </a>
    </div>
  )
}

export default Footer