import React from 'react'
import Navbar from '../components/Navbar'

const Contact = () => {
  return (
    <>
        <Navbar/>
        <div className='absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%]'>
          <h1 className='text-5xl'>
            In the Contact component it doesn't have any specific details , because In the Figma there is no information given yet  in the Contact component
          </h1>
        </div>
    </>
  )
}

export default Contact